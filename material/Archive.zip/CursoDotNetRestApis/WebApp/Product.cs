﻿using System;
namespace WebApp
{
    public class Product
    {
        public int id { get; set; }
        public string name { get; set; }
    }
}
