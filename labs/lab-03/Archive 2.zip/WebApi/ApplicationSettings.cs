﻿using System;
namespace WebApi
{
    public class ApplicationSettings
    {

        public String Variable { get; set; }

    }
}

