﻿using System;
using Newtonsoft;

namespace ConsoleApp
{
    public class Person
    {
        public int Id { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
